/*
 * This sample shows how to use ResultSet methods
 to read names from the EMPLOYEE table
 */

// You need to import the java.sql package to use JDBC
import java.sql.*;

public class EmployeeRSMethod
{
  public static void main (String args []) throws Exception
  {

     String url = "jdbc:mysql://cs377db.mathcs.emory.edu:3306/";
     String dbName = "companyDB";
     String userName = "cs377";
     String password = "cs377_s17";
     String sslVer = "?useSSL=false";


     // Load the Oracle JDBC driver
     Class.forName("com.mysql.jdbc.Driver");

     // Connect to the database
     Connection conn = null;
     conn = DriverManager.getConnection(url + dbName + sslVer,userName,password);


     // Create a Statement
     Statement stmt = conn.createStatement ();

     // Select the ENAME column from the EMP table
     ResultSet rset = stmt.executeQuery ("select * from employee");
     System.out.println("Straightforward Read ======");
     // Iterate through the result and print the employee names
     while (rset.next ())
     {
          System.out.println (rset.getString (1) + " " 
			       + rset.getString (2) + " "
			       + rset.getString (3) + " "
			       + rset.getString(4)
			     );
     }

     System.out.println("============================");
     System.out.println("beforeFirst Read ======");
     rset.beforeFirst();

     // Iterate through the result and print the employee names
     while (rset.next ())
     {
          System.out.println (rset.getString (1) + " "
                               + rset.getString (2) + " "
                               + rset.getString (3) + " "
                               + rset.getString(4)
                             );
     }

     System.out.println("============================");
     System.out.println("first Read ======");
     rset.first();

     // Iterate through the result and print the employee names
     while (rset.next ())
     {
          System.out.println (rset.getString (1) + " "
                               + rset.getString (2) + " "
                               + rset.getString (3) + " "
                               + rset.getString(4)
                             );
     }

     System.out.println("============================");
     System.out.println("Absolute(3) Read ======");
     rset.absolute(3);
     
     // Iterate through the result and print the employee names
     while (rset.next ())
     {
          System.out.println (rset.getString (1) + " "
                               + rset.getString (2) + " "
                               + rset.getString (3) + " "
                               + rset.getString(4)
                             );
     }


     // Close the ResultSet
     rset.close();

     // Close the Statement
     stmt.close();

     // Close the connection
     conn.close();   
  }
}
