<?php
    // prints hello world
    echo "Hello World!";
?>