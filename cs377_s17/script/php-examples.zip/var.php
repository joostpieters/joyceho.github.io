<?php
  $a = 1;
  $A = 2;

  print("a = " . $a . "\n");    # . is string concatenation
  print("A = " . $A . "\n");    # Var name is case sensitive !
  print("b = " . $b . "\n");    # Warning, not fatal !
?>