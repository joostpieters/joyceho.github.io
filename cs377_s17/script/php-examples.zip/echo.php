<html> 
<head> 
<title> Form1 test </title>
</head>
<body> 
<HR>   
<B>    
<?php 
# ------------------------------------------------------------------
# PHP program: echo the data send in the "inp" field by the form
# ------------------------------------------------------------------
   $data = $_POST['inp'] ;
   print("Post Data is $data \n");
?>    
</B>   
<HR>   
</body>
</html>
