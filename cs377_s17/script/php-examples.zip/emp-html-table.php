<html>
<head>
<title> MySQL Test 1</title>
</head>
<body>
     
<H3>
<HR>
Accessing a Database through a <I>Web browser</I> using PHP
<HR>
</H3>
<P> 
<UL>
     
<?php
$conn = mysqli_connect("cs377db.mathcs.emory.edu", "cs377", "cs377_s17", "companyDB");
     
if (mysqli_connect_errno())            # -----------  check connection error
{      
   printf("Connect failed: %s\n", mysqli_connect_error());
   exit(1);
}      
        
$query = 'select fname, lname, salary from employee';
     
if ( ! ( $result = mysqli_query($conn, $query)) )      # Execute query
{      
   printf("Error: %s\n", mysqli_error($conn));
   exit(1);
}      
     
printf("<P>\nSelect returned %d rows.\n<P>\n", mysqli_num_rows($result));
             
print("<P>\n");       
print("<UL>\n");    
print("<TABLE bgcolor=\"lightyellow\" BORDER=\"5\">\n");
             
while ( $row = mysqli_fetch_assoc( $result ) )
{         
   print("<TR>\n");     # Start row of HTML table
   foreach ($row as $key => $value)
   {         
    print ("<TD>" . $value . "</TD>");         # One item in row
   }         
   print ("</TR>\n");   # End row of HTML table
}         
                    
print("</TABLE>\n");
print("</UL>\n");   
print("<P>\n");    

mysqli_free_result($result);
     
mysqli_close($conn);
?>     
     
</UL>
<P> 
<HR>
<HR>
</body>
</html>
