<?php
 $a = 1;                # Global a
 print("Main: a = " . $a . "\n");
 f($a);
 print("Main: a = " . $a . "\n");

 function  f( )
 {
    global $a;      # ******** a will now access a global variable
    print("f before: a = " . $a . "\n");  # Global scope a          
    $a = 4444;
    print("f before: a = " . $a . "\n");  # Global scope a 
 }

 print("Main: a = " . $a . "\n");
?>