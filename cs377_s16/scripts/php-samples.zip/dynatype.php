<?php
   $a = 12;
   print ("a = " . $a . " Type of a = " . gettype($a) . "\n");         
   $a = 12.0;
   print ("a = " . $a . " Type of a = " . gettype($a) . "\n");
   $a = "12";
   print ("a = " . $a . " Type of a = " . gettype($a) . "\n");
   $a = true;
   print ("a = " . $a . " Type of a = " . gettype($a) . "\n");
?>