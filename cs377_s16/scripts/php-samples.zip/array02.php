<?php
    $A[0] = 123;
    $A[2] = 'def';
    $A[4] = true;

    print("# elements = " . count($A) . "\n");            # prints 3

    for ($i = 0; $i <= 4; $i++ )
    {
          print($A[$i] . "\n");
    }
?>
