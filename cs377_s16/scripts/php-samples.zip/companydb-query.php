<html>
   <head>
   <title> CS377 MySQL Web client</title>
   </head>
   <body>
      
   <H3>
   <HR>
   Answer to the query
   <HR>
   </H3>
   <P> 
   <UL>
      
   <?php
      
   $conn = mysqli_connect("cs377spring16.mathcs.emory.edu", "cs377", "Dj@B5WFd3Pf+");
      
   if (mysqli_connect_errno())            # -----------  check connection error
   {      
      printf("Connect failed: %s\n", mysqli_connect_error());
      exit(1);
   }      
      
   if ( ! mysqli_select_db($conn, "companyDB") )          # Select DB
   {      
      printf("Error: %s\n", mysqli_error($conn));
      exit(1);
   }      
        
   $query = $_POST['query'];

   print("<UL><TABLE bgcolor=\"#FFEEEE\" BORDER=\"5\">\n");
   print("<TR> <TD><FONT color=\"blue\"><B><PRE>\n");
   print( $query );   # echo the query 
   print("</PRE></B></FONT></TD></TR></TABLE></UL>\n");
   print("<P><HR><P>\n");
      
   if ( ! ( $result = mysqli_query($conn, $query)) )      # Execute query
   {      
      printf("Error: %s\n", mysqli_error($conn));
      exit(1);
   }      
      
   print("<UL>\n");
   print("<TABLE bgcolor=\"lightyellow\" BORDER=\"5\">\n");
      
   $printed = false;
   
   while ( $row = mysqli_fetch_assoc( $result ) )
   {      
      if ( ! $printed )
      {   
     $printed = true;                 # Print header once...
      
     print("<TR bgcolor=\"lightcyan\">\n");
     foreach ($row as $key => $value)
     {
        print ("<TH>" . $key . "</TH>");             # Print attr. name
     }
     print ("</TH>\n");
      }   
      
      
      print("<TR>\n");
      foreach ($row as $key => $value)
      {   
     print ("<TD>" . $value . "</TD>");
      }   
      print ("</TR>\n");
   }      
   print("</TABLE>\n");
   print("</UL>\n");
   print("<P>\n");
      
   mysqli_free_result($result);
      
   mysqli_close($conn);

   ?>     
      
   </UL>
   <P> 
   <HR>
   <HR>
   <HR>
   <HR>