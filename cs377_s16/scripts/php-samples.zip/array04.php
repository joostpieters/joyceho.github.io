<?php
   $A = array (     # ******* True associative array !!!
                  "CS377" => "Cheung",
                  "CS450" => "Km",
                  "CS323" => "Grigni"
                );

   print("# elements = " . count($A) . "\n");            # prints 3

   foreach ( $A as $i => $v )
   {
      print("i = $i , v = $v \n");
   }

   print "\n";

   # ===================================
   # Alternate syntax:
   # ===================================

   foreach ( $A as $i => $v )
   {
      print("i = $i , A[$i] = $A[$i] \n");
   }
?>
