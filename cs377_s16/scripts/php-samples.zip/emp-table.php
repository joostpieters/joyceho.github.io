<?php

$conn = mysqli_connect("cs377spring16.mathcs.emory.edu", "cs377", "Dj@B5WFd3Pf+", "companyDB");
if (mysqli_connect_errno())            # -----------  check connection error
{      
   printf("Connect failed: %s\n", mysqli_connect_error());
   exit(1);
}

$query = 'select fname, lname, salary from employee';
$result = mysqli_query($conn, $query);
if ( ! ( $result = mysqli_query($conn, $query)) )      # Execute query
{      
   printf("Error: %s\n", mysqli_error($conn));
   exit(1);
}

$printed = false;

while ($row = mysqli_fetch_assoc( $result ))
{
   if ( ! $printed )
   {
      $printed = true;                 // Print once...

      foreach ($row as $key => $value)
      {
         print $key . "\t";             // Print attr. name
      }
      print "\n---------------------------------\n";
   }

   foreach ($row as $key => $value)
   {
      print $value . "\t";
   }
   print "\n";
}

mysqli_free_result($result);
mysqli_close($conn);

?>
