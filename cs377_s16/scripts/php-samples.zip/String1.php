<?php

  $x = "Hello World !";

  print 'Single-quoted string. This is $x';
  print"\n";
  print "Double-quoted string. This is $x";
  print"\n";
  print <<<MARKER
    Here document text.. type away... This is $x
    Another line. Just keep going - until a line with MARKER is found
MARKER
;
  print"\n";
  print <<<MARKER2
    Here document text.. type away... This is \$x
    Another line. Just keep going - until a line with MARKER is found
MARKER2
;
  print "\n";
?>
