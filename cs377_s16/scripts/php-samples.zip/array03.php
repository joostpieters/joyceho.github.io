<?php
   $A[0] = 123;
   $A[2] = 'def';
   $A[4] = true;

   print("# elements = " . count($A) . "\n");            # prints 3

   foreach ( $A as $i => $v )
   {
        print("i = $i , v = $v \n");
   }

   print "\n";

   # ===================================
   # Alternate syntax:
   # ===================================

   foreach ( $A as $i => $v )
   {
        print("i = $i , A[$i] = $A[$i] \n");
   }
?>
