<html>
<head>
<title> PHP Test </title>
</head>
<body>

<UL>
Welcome stranger, here is your lucky number:
<?php print rand(1, 1000); ?>
</UL>

</body>
</html>