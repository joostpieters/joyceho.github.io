<?php
    $a = square(4);
    print("Square of 4 = " . $a . "\n");               

    # Function definition
    function  square( $x )
    {
        $r = $x * $x ;
        return( $r );
    }
?>