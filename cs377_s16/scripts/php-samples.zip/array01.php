<?php
# ---------------------------------------------
# How to define an associative array in general
# ---------------------------------------------
  $A = array(
              0 => 1234,
                 1 => 'ABC',
                 2 => 'DEF'
            );                # elements 0, 1, 2

  for ( $i = 0; $i < 3; $i++ )
  {
        print ($A[$i] . "\n");
  }

  print ("\n");
# ---------------------------------------------
# Associative array with numeric indexes
# ---------------------------------------------
  $B = array(1234, 'ABC',  'DEF');  # elements 0, 1, 2

  for ( $i = 0; $i < 3; $i++ )
  {
        print ($B[$i] . "\n");
  }

  print ("\n");
# ---------------------------------------------
# More "traditional" way to create an array
# ---------------------------------------------
  $C[0] = 1234;
  $C[1] = 'ABC';
  $C[2] = 'DEF';
  
  for ( $i = 0; $i < 3; $i++ )
  {
	print ($C[$i] . "\n");
  }

?>
